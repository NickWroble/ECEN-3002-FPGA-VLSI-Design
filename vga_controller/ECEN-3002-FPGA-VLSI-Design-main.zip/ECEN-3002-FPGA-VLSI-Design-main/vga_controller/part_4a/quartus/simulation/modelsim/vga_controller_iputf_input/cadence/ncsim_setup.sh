

ncvlog "C:/Users/nickw/Documents/GitHub/ECEN_3002/ECEN_3002_FPGA_VLSI_Design/vga_controller/part_4a/quartus/vga_pll_sim/vga_pll.vo"    
ncvlog "C:/Users/nickw/Documents/GitHub/ECEN_3002/ECEN_3002_FPGA_VLSI_Design/vga_controller/part_4a/quartus/pll_720p_sim/pll_720p.vo"  
ncvlog "C:/Users/nickw/Documents/GitHub/ECEN_3002/ECEN_3002_FPGA_VLSI_Design/vga_controller/part_4a/quartus/pll_1080p_sim/pll_1080p.vo"
